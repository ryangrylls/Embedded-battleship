'use strict';
/**
 * Position constructor
 * @param x position
 * @param y position
 * @constructor
 */
BattleShip.Position = function(x, y) {
    this.x = x;
    this.y = y;
}