'use strict';
/**
 * Global Namespace
 */
var BattleShip = {};

window.BattleShip = BattleShip;